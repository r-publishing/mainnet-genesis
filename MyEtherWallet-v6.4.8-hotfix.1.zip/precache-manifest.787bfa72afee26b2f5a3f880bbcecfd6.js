self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2a8bf02e75c54015c0b000b10c42d45b",
    "url": ".well-known/security.txt"
  },
  {
    "revision": "64bb17c44d6a96d1a568",
    "url": "css/app~2e7e5c58.9e1e7d06.css"
  },
  {
    "revision": "8194ab8a780959acd394",
    "url": "css/app~5a11b65b.c83020d1.css"
  },
  {
    "revision": "3e729b3051c01ebeb12a",
    "url": "css/app~748942c6.2dc834cd.css"
  },
  {
    "revision": "c1c5701acae08fce10c2",
    "url": "css/app~f71cff67.c5b4a385.css"
  },
  {
    "revision": "bcbc7edc3552469e2c55",
    "url": "css/chunk-vendors~6e8b5f81.8e63b9e5.css"
  },
  {
    "revision": "38ece611421381f734d8",
    "url": "css/chunk-vendors~ec8c427e.5ba64f85.css"
  },
  {
    "revision": "61fcbdbe4c1fde642b6e688b7e1e5b4a",
    "url": "favicon.png"
  },
  {
    "revision": "3ac50b5b36eb2f11b000dce1792d0bb0",
    "url": "fonts/materialdesignicons-webfont.3ac50b5b.ttf"
  },
  {
    "revision": "7ec5dab7e7ff250971d2ff50379778dc",
    "url": "fonts/materialdesignicons-webfont.7ec5dab7.woff2"
  },
  {
    "revision": "9cacdc876e2049988fcab540c21738d5",
    "url": "fonts/materialdesignicons-webfont.9cacdc87.eot"
  },
  {
    "revision": "9d243c168a4f1c2cb3cec74884344de7",
    "url": "fonts/materialdesignicons-webfont.9d243c16.woff2"
  },
  {
    "revision": "a0711490bcd581b647329230b3e915cf",
    "url": "fonts/materialdesignicons-webfont.a0711490.woff"
  },
  {
    "revision": "a0d13d16cc2f3647680d9f1ff003f58b",
    "url": "fonts/materialdesignicons-webfont.a0d13d16.woff"
  },
  {
    "revision": "a32fa1f27abbfa96ff2f79e1ade723d5",
    "url": "fonts/materialdesignicons-webfont.a32fa1f2.eot"
  },
  {
    "revision": "b62641afc9ab487008e996a5c5865e56",
    "url": "fonts/materialdesignicons-webfont.b62641af.ttf"
  },
  {
    "revision": "5cb7edfceb233100075dc9a1e12e8da3",
    "url": "fonts/roboto-v20-latin-100.5cb7edfc.woff"
  },
  {
    "revision": "6906d86d9bc67920de4234d88edbc6d9",
    "url": "fonts/roboto-v20-latin-100.6906d86d.eot"
  },
  {
    "revision": "7370c3679472e9560965ff48a4399d0b",
    "url": "fonts/roboto-v20-latin-100.7370c367.woff2"
  },
  {
    "revision": "ff1e90ce3376de433388ec3fc415aa0f",
    "url": "fonts/roboto-v20-latin-100.ff1e90ce.ttf"
  },
  {
    "revision": "806854d4422d0bd79e0f8c87c329a568",
    "url": "fonts/roboto-v20-latin-300.806854d4.ttf"
  },
  {
    "revision": "b00849e00f4c2331cddd8ffb44a6720b",
    "url": "fonts/roboto-v20-latin-300.b00849e0.woff"
  },
  {
    "revision": "bda729dbf749cbb9a8e480fa2deec2e9",
    "url": "fonts/roboto-v20-latin-300.bda729db.eot"
  },
  {
    "revision": "ef7c6637c68f269a882e73bcb57a7f6a",
    "url": "fonts/roboto-v20-latin-300.ef7c6637.woff2"
  },
  {
    "revision": "020c97dc8e0463259c2f9df929bb0c69",
    "url": "fonts/roboto-v20-latin-500.020c97dc.woff2"
  },
  {
    "revision": "260c8072feca314957defd2ad4ccc0ee",
    "url": "fonts/roboto-v20-latin-500.260c8072.eot"
  },
  {
    "revision": "87284894879f5b1c229cb49c8ff6decc",
    "url": "fonts/roboto-v20-latin-500.87284894.woff"
  },
  {
    "revision": "8c608256fb0273e3a36e6b603f71f213",
    "url": "fonts/roboto-v20-latin-500.8c608256.ttf"
  },
  {
    "revision": "2735a3a69b509faf3577afd25bdf552e",
    "url": "fonts/roboto-v20-latin-700.2735a3a6.woff2"
  },
  {
    "revision": "4570b93ae0caba2b938e2ddf091099ea",
    "url": "fonts/roboto-v20-latin-700.4570b93a.eot"
  },
  {
    "revision": "96559ffb5be917f1ce9f748bf4f34732",
    "url": "fonts/roboto-v20-latin-700.96559ffb.ttf"
  },
  {
    "revision": "adcde98f1d584de52060ad7b16373da3",
    "url": "fonts/roboto-v20-latin-700.adcde98f.woff"
  },
  {
    "revision": "22acb397075fc000039235655d658600",
    "url": "fonts/roboto-v20-latin-900.22acb397.ttf"
  },
  {
    "revision": "352cf1ddd096799baa560159884fb515",
    "url": "fonts/roboto-v20-latin-900.352cf1dd.eot"
  },
  {
    "revision": "9b3766ef4a402ad3fdeef7501a456512",
    "url": "fonts/roboto-v20-latin-900.9b3766ef.woff2"
  },
  {
    "revision": "bb1e4dc6333675d11ada2e857e7f95d7",
    "url": "fonts/roboto-v20-latin-900.bb1e4dc6.woff"
  },
  {
    "revision": "329ae1c377b1fb667f5be6abd50327fc",
    "url": "fonts/roboto-v20-latin-regular.329ae1c3.ttf"
  },
  {
    "revision": "479970ffb74f2117317f9d24d9e317fe",
    "url": "fonts/roboto-v20-latin-regular.479970ff.woff2"
  },
  {
    "revision": "4be1a572fca40bcb2202504cb17aed91",
    "url": "fonts/roboto-v20-latin-regular.4be1a572.eot"
  },
  {
    "revision": "60fa3c0614b8fb2f394fa29944c21540",
    "url": "fonts/roboto-v20-latin-regular.60fa3c06.woff"
  },
  {
    "revision": "bd0e4b0f94cc598aac4271ef9b436fac",
    "url": "icons/android-chrome-192x192.png"
  },
  {
    "revision": "5c3f4f5a767158cbb40860c5abc98e5d",
    "url": "icons/android-chrome-512x512.png"
  },
  {
    "revision": "249c7d47c0e74e732425e3c5ae85c863",
    "url": "icons/apple-touch-icon-120x120.png"
  },
  {
    "revision": "c593277cf5779720db2adbfb3aae072f",
    "url": "icons/apple-touch-icon-152x152.png"
  },
  {
    "revision": "9b02a72b8c3770760bc60919e637d45c",
    "url": "icons/apple-touch-icon-180x180.png"
  },
  {
    "revision": "970f2941076569ea2b7c7dd83a3509a6",
    "url": "icons/apple-touch-icon-60x60.png"
  },
  {
    "revision": "676e76fb337fc9ad68ed9a9c00d92fac",
    "url": "icons/apple-touch-icon-76x76.png"
  },
  {
    "revision": "a8c4cea5a22ecfdb59cf2b463ea581a5",
    "url": "icons/apple-touch-icon.png"
  },
  {
    "revision": "5456fd1d3a46a1fcbe0e133dfa9924e0",
    "url": "icons/favicon-16x16.png"
  },
  {
    "revision": "775f0e4f9a7d4ddc94b60f79e67e0a24",
    "url": "icons/favicon-32x32.png"
  },
  {
    "revision": "e91b3266af8075cfd4172fca87688490",
    "url": "icons/icon192.png"
  },
  {
    "revision": "0279aae5bee03dd78532beeaf142ad82",
    "url": "icons/msapplication-icon-144x144.png"
  },
  {
    "revision": "1887fd97619a9a361c1ead579c7518bf",
    "url": "icons/mstile-150x150.png"
  },
  {
    "revision": "1a39deb07f580bfe50f2095c8491dcc5",
    "url": "icons/safari-pinned-tab.svg"
  },
  {
    "revision": "1d8b91cf791ca22a711b0e03301d8bab",
    "url": "img/1inch.1d8b91cf.png"
  },
  {
    "revision": "730ed530612ef984039fcef57ba0f87d",
    "url": "img/Changelly.730ed530.png"
  },
  {
    "revision": "050a40e7631a85a54f788300e6c9d55a",
    "url": "img/Curve.050a40e7.png"
  },
  {
    "revision": "3c6d4bb520d5d3c3ebe406d18cdea5c7",
    "url": "img/Sushiswap.3c6d4bb5.png"
  },
  {
    "revision": "73c82235c38e3da1bd8dd1b6c11a6643",
    "url": "img/Synthetix.73c82235.png"
  },
  {
    "revision": "d0b63a1627e0bb26b04f4b16befed322",
    "url": "img/alex.d0b63a16.jpg"
  },
  {
    "revision": "4ebca01588f68ef7087ed2bca34c79f9",
    "url": "img/andrew-dao.4ebca015.jpg"
  },
  {
    "revision": "44e0cfb1d3fb73bda82d1a352f57e057",
    "url": "img/andrew.44e0cfb1.jpg"
  },
  {
    "revision": "7e397372fec8c88f49ba97a536880e70",
    "url": "img/bb02-pw-entry.7e397372.gif"
  },
  {
    "revision": "179a6a5d6b443cf0005a6049c110b269",
    "url": "img/bg-404.179a6a5d.svg"
  },
  {
    "revision": "581517c8a536ca0b28249ae41ee62f28",
    "url": "img/bg-bubbles.581517c8.png"
  },
  {
    "revision": "3f40a32ba7145d1b4196472b0c3db12c",
    "url": "img/bg-circle-triangle.3f40a32b.png"
  },
  {
    "revision": "a7a3632615a47f090a7758c9821d12e1",
    "url": "img/bg-dapps-center.a7a36326.png"
  },
  {
    "revision": "cba4b0eda7efc8ca2020cb8e0780c96c",
    "url": "img/bg-dapps-stake.cba4b0ed.svg"
  },
  {
    "revision": "45134cf04ea4b42ba342349ca691219f",
    "url": "img/bg-ens.45134cf0.png"
  },
  {
    "revision": "77d61caa462bc75166f33c2c562b0b5c",
    "url": "img/bg-erroe-msg.77d61caa.svg"
  },
  {
    "revision": "13c2a11df9d502808c4bcb5af55bef75",
    "url": "img/bg-half-circle.13c2a11d.png"
  },
  {
    "revision": "313ea5b0d4eb6bbc036bacce7a643231",
    "url": "img/bg-home-spaceman-and-dog.313ea5b0.svg"
  },
  {
    "revision": "71563aac8aef529254dfdd6450dea2c0",
    "url": "img/bg-homepage-spaceman-center.71563aac.svg"
  },
  {
    "revision": "499743647650fe33591001c56530d39b",
    "url": "img/bg-homepage.49974364.svg"
  },
  {
    "revision": "eef0d489c9b0d2d7b0cc17e08f1ddc07",
    "url": "img/bg-left-bubble.eef0d489.png"
  },
  {
    "revision": "a6098eb5c3840263c176efc8a2744840",
    "url": "img/bg-light.a6098eb5.jpg"
  },
  {
    "revision": "f8ae4bde273ba114cb4c38ac45945f5a",
    "url": "img/bg-mew-wallet.f8ae4bde.png"
  },
  {
    "revision": "9b9edde8c806e1f0f2a5463681715d84",
    "url": "img/bg-mountains.9b9edde8.png"
  },
  {
    "revision": "933d5f0be872ab3d11fea5af545cc7c9",
    "url": "img/bg-right-bubble.933d5f0b.png"
  },
  {
    "revision": "1a662794ded539c7dbf14830c54c25ad",
    "url": "img/bg-small-half-circle.1a662794.png"
  },
  {
    "revision": "ab600882659632fa9d41cc4b5930512d",
    "url": "img/bg-spaceman.ab600882.png"
  },
  {
    "revision": "50068b152544bc5b2c0b1c57f4248891",
    "url": "img/bg-unstoppable-domain.50068b15.png"
  },
  {
    "revision": "62a871a5f8e0e0186af772a3ce70e223",
    "url": "img/bg-waves-color.62a871a5.png"
  },
  {
    "revision": "e35f82f0efc9e86cb6295f9d30c32171",
    "url": "img/bg-waves.e35f82f0.svg"
  },
  {
    "revision": "967e1f93f607f5ceb3f905fa658e606b",
    "url": "img/billfodl.967e1f93.png"
  },
  {
    "revision": "4885c18a2a8fe610c6a2240b149afc52",
    "url": "img/bitbox.4885c18a.png"
  },
  {
    "revision": "4b910905e64d565fe5d792e681a9ea5c",
    "url": "img/bitbox.4b910905.png"
  },
  {
    "revision": "1309a8a737d65ff13e7398f5d20cce83",
    "url": "img/bitbox02-locked.1309a8a7.png"
  },
  {
    "revision": "de769c0897eea0bc6db59b202b74b341",
    "url": "img/bitbox02-welcome.de769c08.png"
  },
  {
    "revision": "270e6de15cb7a7476b14476595bcebe1",
    "url": "img/bitmap.270e6de1.png"
  },
  {
    "revision": "6586394793869bfbc037ea7e98590bc3",
    "url": "img/brian.65863947.jpg"
  },
  {
    "revision": "884db4ca85e7c3dbfb2685386497ef1f",
    "url": "img/brionne.884db4ca.jpg"
  },
  {
    "revision": "f1e5a2375516bbd35149b64669f461e3",
    "url": "img/brittany.f1e5a237.jpg"
  },
  {
    "revision": "e5f46f6e50de67a1b3957b88ca771f53",
    "url": "img/bsc.e5f46f6e.svg"
  },
  {
    "revision": "6e701c881452b39af84ab52fa1eece77",
    "url": "img/btc.6e701c88.png"
  },
  {
    "revision": "bad39c4fc54b296851beb629a134c4b8",
    "url": "img/button-app-store.bad39c4f.png"
  },
  {
    "revision": "cb4296cb7bc1207f61bcfbfe9166c1e3",
    "url": "img/button-app-store.cb4296cb.svg"
  },
  {
    "revision": "bc93cea11dca8d35b897ef58fe6a44c1",
    "url": "img/button-circle-right-arrow.bc93cea1.svg"
  },
  {
    "revision": "0b0baeb13a319a86d41b9efaa72c2848",
    "url": "img/button-play-store.0b0baeb1.png"
  },
  {
    "revision": "eb328107d90f67b82403c56936ad9888",
    "url": "img/button-play-store.eb328107.svg"
  },
  {
    "revision": "fb3c1d5b2db862fe05d37362418de036",
    "url": "img/changelly.fb3c1d5b.png"
  },
  {
    "revision": "f71c13f1a0e69bf38854da0e7a94bdd8",
    "url": "img/chindalath.f71c13f1.jpg"
  },
  {
    "revision": "77bd1068fe0c37d99b033feb25af42b4",
    "url": "img/christian.77bd1068.jpg"
  },
  {
    "revision": "826d1e727efb2e309c1134d3af122c56",
    "url": "img/coolwallet-sample.826d1e72.png"
  },
  {
    "revision": "3cd3d656625183291792aa8f67929da6",
    "url": "img/coolwallet.3cd3d656.svg"
  },
  {
    "revision": "a214e7b4de1d36f7d52e97246dcaf06f",
    "url": "img/dai.a214e7b4.png"
  },
  {
    "revision": "947049c087c44f542bfedd37d3e7440a",
    "url": "img/david.947049c0.jpg"
  },
  {
    "revision": "ad3bab0d4363ccc278de302e609bc7e7",
    "url": "img/etc.ad3bab0d.svg"
  },
  {
    "revision": "a1472dde86ed92f0a803a38690bb4ed4",
    "url": "img/eth-blocks-3.a1472dde.png"
  },
  {
    "revision": "53bb9341a74e6c26281afb4be800b991",
    "url": "img/eth-blocks-6.53bb9341.png"
  },
  {
    "revision": "46f7c5099e30b470f3f25995278adab1",
    "url": "img/eth-blocks-qrs.46f7c509.svg"
  },
  {
    "revision": "ad11058d846dfaab031d0beb1bf7ab33",
    "url": "img/eth-dark-navy.ad11058d.svg"
  },
  {
    "revision": "e74e2c699406a104c1c94cd12d941193",
    "url": "img/eth.e74e2c69.svg"
  },
  {
    "revision": "1e88cb93e18df04a81857fc64ad6f75d",
    "url": "img/finney.1e88cb93.png"
  },
  {
    "revision": "a360457693ab501e4c42c4789c197b0f",
    "url": "img/gage.a3604576.jpg"
  },
  {
    "revision": "9cc7b318769486988bea20775a454a01",
    "url": "img/gamaliel.9cc7b318.jpg"
  },
  {
    "revision": "ddc250127189a3b4ee4802e6c2493757",
    "url": "img/github.ddc25012.svg"
  },
  {
    "revision": "265cdedb938ea57e707ebce686a7f16f",
    "url": "img/go.265cdedb.svg"
  },
  {
    "revision": "5d8fadf4799eb02f12ee156c7623b617",
    "url": "img/icon-appstore-android-dark.5d8fadf4.svg"
  },
  {
    "revision": "63762eedd5c3f65e43b841d871a3ac02",
    "url": "img/icon-appstore-apple-dark.63762eed.svg"
  },
  {
    "revision": "ec7197eef11b774ef6023056cdb48501",
    "url": "img/icon-arrow-up.ec7197ee.svg"
  },
  {
    "revision": "3c28f39dceae0ce7c61ae342ac207042",
    "url": "img/icon-bitbox.3c28f39d.svg"
  },
  {
    "revision": "147159c088960505064d6b7d2ab7c522",
    "url": "img/icon-btc-gold.147159c0.svg"
  },
  {
    "revision": "9fb32c79b025aded08e47c363d61a289",
    "url": "img/icon-btc-white.9fb32c79.svg"
  },
  {
    "revision": "7551a462b6aff3a7cb12571940834b2f",
    "url": "img/icon-buy-eth-mew.7551a462.svg"
  },
  {
    "revision": "7749fb50b5f15e3356064f8fee3934ae",
    "url": "img/icon-buy-token-white.7749fb50.svg"
  },
  {
    "revision": "e1c3fc6320ba451eca4310d8f7508ab2",
    "url": "img/icon-checked.e1c3fc63.svg"
  },
  {
    "revision": "82aab93bf704145f8592fa2669896041",
    "url": "img/icon-colorful-eth.82aab93b.svg"
  },
  {
    "revision": "fe05f5ad03176bc82c1b173a4108f58e",
    "url": "img/icon-community-mew.fe05f5ad.svg"
  },
  {
    "revision": "5cb59b0967509f7220ad1d002afd24b7",
    "url": "img/icon-contract-mew.5cb59b09.svg"
  },
  {
    "revision": "4c335d0a0fbc34b47013c05ff511b553",
    "url": "img/icon-coolwallet.4c335d0a.svg"
  },
  {
    "revision": "8901d68ccb7390a5b4d159db322d343d",
    "url": "img/icon-customer-support.8901d68c.svg"
  },
  {
    "revision": "242c01c09d839845bf07ce164d22cd2f",
    "url": "img/icon-dapp-eth-blocks.242c01c0.svg"
  },
  {
    "revision": "42849253626161960c34fe1578b6d1e0",
    "url": "img/icon-dapp-lock.42849253.png"
  },
  {
    "revision": "87c3600759fd8449d010d46c87731243",
    "url": "img/icon-dapp-makerdao.87c36007.png"
  },
  {
    "revision": "b96afc779c69e6c21734ddd2415fcea2",
    "url": "img/icon-dapps-mew.b96afc77.svg"
  },
  {
    "revision": "e07b6c5e6be09e55ab79b58eb0af82c7",
    "url": "img/icon-eth-blocks-logo.e07b6c5e.png"
  },
  {
    "revision": "638adc7608aae1294d0e0333531c378b",
    "url": "img/icon-eth-blue.638adc76.svg"
  },
  {
    "revision": "a4ac3058baead0c79e75c4585bc0a544",
    "url": "img/icon-eth-grey.a4ac3058.svg"
  },
  {
    "revision": "a1338ac21d257a46ad81ffc4849bb011",
    "url": "img/icon-eth-white.a1338ac2.svg"
  },
  {
    "revision": "82d31ed7fbdb6f4a9518351cfab6b67a",
    "url": "img/icon-ethvm.82d31ed7.png"
  },
  {
    "revision": "7b784ab3f0d95aedc9cade90edd46008",
    "url": "img/icon-faces-mew.7b784ab3.svg"
  },
  {
    "revision": "2090db1ee97496b1015fcf33e7c048a3",
    "url": "img/icon-fiat-white.2090db1e.svg"
  },
  {
    "revision": "6a9b1969497fa9e1f86a93539bcf52b2",
    "url": "img/icon-github-dark.6a9b1969.svg"
  },
  {
    "revision": "63f3f69ff88822d814834c0b0751933f",
    "url": "img/icon-hardware-wallet.63f3f69f.png"
  },
  {
    "revision": "c6b6496fb8416be4467923eb9f320364",
    "url": "img/icon-keepkey.c6b6496f.svg"
  },
  {
    "revision": "956cbf72057a9c02cab8202b488ef993",
    "url": "img/icon-keystore-file.956cbf72.svg"
  },
  {
    "revision": "b4b1615e9417cf07b418258405607fc8",
    "url": "img/icon-keystore-mew.b4b1615e.png"
  },
  {
    "revision": "deac52f186c3f1aa2a17cf081bb85471",
    "url": "img/icon-ledger.deac52f1.svg"
  },
  {
    "revision": "959d240677f788e50cff3d00081a04ae",
    "url": "img/icon-menu.959d2406.svg"
  },
  {
    "revision": "ec409d6dfc8c6912713160507505c2c0",
    "url": "img/icon-message-mew.ec409d6d.svg"
  },
  {
    "revision": "1b2f87fd48c70c704dcb978eae71d99f",
    "url": "img/icon-message2-mew.1b2f87fd.svg"
  },
  {
    "revision": "ece1afecfd69b13382c4db0616a03f9a",
    "url": "img/icon-mew-connect.ece1afec.png"
  },
  {
    "revision": "ef0ea2225214d534d84d2b051a7ed8c4",
    "url": "img/icon-mew-cx.ef0ea222.png"
  },
  {
    "revision": "4bdea8d3f8935fbdbb4367537eac4867",
    "url": "img/icon-mew-logo.4bdea8d3.svg"
  },
  {
    "revision": "f29574d35392dc86ba4124d1c8ba7938",
    "url": "img/icon-mew-wallet.f29574d3.png"
  },
  {
    "revision": "7c3d34fc57b200b5802a3431bf28392c",
    "url": "img/icon-mnemonic.7c3d34fc.svg"
  },
  {
    "revision": "97fed0106dc4c28183a31a3357f7fbe9",
    "url": "img/icon-nft-mew.97fed010.svg"
  },
  {
    "revision": "b2df08331800c0e8594f415b956472bb",
    "url": "img/icon-nft-placeholder.b2df0833.png"
  },
  {
    "revision": "09e377beef5a4a9bb6582d3ddc0ab369",
    "url": "img/icon-notifications.09e377be.svg"
  },
  {
    "revision": "4f0c3f2d89a037f1b46e52250a633e9d",
    "url": "img/icon-offline-mew.4f0c3f2d.svg"
  },
  {
    "revision": "46f19317632e4f7fd4a875b4449be912",
    "url": "img/icon-puppy-mew.46f19317.svg"
  },
  {
    "revision": "75bf471c040e6a5338adae11b2b3b705",
    "url": "img/icon-reddit-dark.75bf471c.svg"
  },
  {
    "revision": "c50441935f6f9f3044aec0e5a3ad8115",
    "url": "img/icon-send-mew.c5044193.svg"
  },
  {
    "revision": "32cdf83cc553fa459a349d08a03c6155",
    "url": "img/icon-shield-checked.32cdf83c.svg"
  },
  {
    "revision": "30075a296d9b1fa79243d259b17c9d5a",
    "url": "img/icon-shield-crossed.30075a29.svg"
  },
  {
    "revision": "8ead6587bc0eb35c1120d0eb9d16da17",
    "url": "img/icon-shield.8ead6587.svg"
  },
  {
    "revision": "4d66b3d4415db9ae40127abb513305c6",
    "url": "img/icon-slack-dark.4d66b3d4.svg"
  },
  {
    "revision": "881a57a1b8588f52602597f860beb9e3",
    "url": "img/icon-sotd.881a57a1.png"
  },
  {
    "revision": "bf286d013f3dd4248924f34056db5787",
    "url": "img/icon-submit-mew.bf286d01.svg"
  },
  {
    "revision": "fadaebc325afe719ac802093ecefdb55",
    "url": "img/icon-support.fadaebc3.svg"
  },
  {
    "revision": "ce4de633b057048f5efc037b07924d74",
    "url": "img/icon-swap.ce4de633.svg"
  },
  {
    "revision": "6ec8ec13ee5658892c4df4aa6d00e7d4",
    "url": "img/icon-telegram-dark.6ec8ec13.svg"
  },
  {
    "revision": "fa55267a18a46746bbd3b7361ae03e74",
    "url": "img/icon-telegram.fa55267a.svg"
  },
  {
    "revision": "43f6d5108aa887b224094ed595303c7f",
    "url": "img/icon-trezor.43f6d510.svg"
  },
  {
    "revision": "201a190a28ace4f00bb3b45255d164a6",
    "url": "img/icon-visa-dark.201a190a.png"
  },
  {
    "revision": "fde9097f71fd4c3228bd2ebc26097ff5",
    "url": "img/icon-wallet-connect.fde9097f.svg"
  },
  {
    "revision": "af4ad70ad3574b9ad11858824985d7d7",
    "url": "img/icon-wallet-link.af4ad70a.png"
  },
  {
    "revision": "17f39c56f96c760fad03744e8768b706",
    "url": "img/jason.17f39c56.jpg"
  },
  {
    "revision": "48c91f5c320177aeaa06c1becc696553",
    "url": "img/jazmine.48c91f5c.jpg"
  },
  {
    "revision": "5568ca5a18d8f575357375674a9b1cfd",
    "url": "img/katya.5568ca5a.jpg"
  },
  {
    "revision": "4c66604602613def42e0169a081fc57b",
    "url": "img/keepkey.4c666046.svg"
  },
  {
    "revision": "82bc8ace7015634f2f8ed9d11e3232fd",
    "url": "img/keepkey.82bc8ace.png"
  },
  {
    "revision": "d7083f29423b7fcfcf7de2225973f9a4",
    "url": "img/keepkey.d7083f29.png"
  },
  {
    "revision": "cd9a1369e46f9f15eac85270c140bd1e",
    "url": "img/keystore-file.cd9a1369.jpg"
  },
  {
    "revision": "b54765292d1b9d2d994bfb7e74097223",
    "url": "img/knc.b5476529.png"
  },
  {
    "revision": "5cb7cc31915d297f22d7a979c2341968",
    "url": "img/kosala.5cb7cc31.jpg"
  },
  {
    "revision": "6105a9fecb7c006a7d0fd6789c1d9ece",
    "url": "img/kyber.6105a9fe.png"
  },
  {
    "revision": "237838237ac9c99226901f74d5d015a6",
    "url": "img/ledger-graphic.23783823.svg"
  },
  {
    "revision": "1a5ee423e4737e8b9e2d95119eb3960c",
    "url": "img/ledger.1a5ee423.png"
  },
  {
    "revision": "5dfe2fc447022e70355a8588c1e1cd8a",
    "url": "img/ledger.5dfe2fc4.svg"
  },
  {
    "revision": "4ad2e0789e92e692a58f237f80c3b9c9",
    "url": "img/link.4ad2e078.png"
  },
  {
    "revision": "5d6f3213f637fb58626f8b06a8a156e7",
    "url": "img/loading-block.5d6f3213.svg"
  },
  {
    "revision": "517f1a5f7155326fd1041a3740e69950",
    "url": "img/logo-billfodl.517f1a5f.png"
  },
  {
    "revision": "a3abdc592bddf9d5ea469d0915eff8b1",
    "url": "img/logo-dark.a3abdc59.svg"
  },
  {
    "revision": "b47b5639868818bd4096e92168838b2d",
    "url": "img/logo-dark.b47b5639.png"
  },
  {
    "revision": "35affe8ada874b588486cedb1fa972dd",
    "url": "img/logo-kid.35affe8a.png"
  },
  {
    "revision": "683cb081dcc86d55df3f96c34b44c845",
    "url": "img/logo-kid.683cb081.svg"
  },
  {
    "revision": "029667b470bbb61f6467fbc8b268f5e5",
    "url": "img/logo-ledger.029667b4.svg"
  },
  {
    "revision": "49b9bcd4463fd2e903a70283c2399567",
    "url": "img/logo-light.49b9bcd4.svg"
  },
  {
    "revision": "7844737a280ad3b6f1b257c8fc635014",
    "url": "img/logo-light.7844737a.png"
  },
  {
    "revision": "5d962d4eff6f2256e53098aae5a360cd",
    "url": "img/logo-mew-dark.5d962d4e.png"
  },
  {
    "revision": "f6482e988b9598d015d4e039c996e69b",
    "url": "img/logo-mew.f6482e98.svg"
  },
  {
    "revision": "5d5fcba7727d9e91c871ccc4d6b11107",
    "url": "img/logo-simple.5d5fcba7.png"
  },
  {
    "revision": "88d6befc6b8f51a36c02ffa789a6a557",
    "url": "img/logo-simple.88d6befc.svg"
  },
  {
    "revision": "7d1254f16244917aff0f7dc0a1e06e24",
    "url": "img/logo-trezor.7d1254f1.svg"
  },
  {
    "revision": "3a0be2cac77d9a789a132021f982fa2a",
    "url": "img/marcus.3a0be2ca.jpg"
  },
  {
    "revision": "78bf8d48a34cfe735f816fa40740af5f",
    "url": "img/matic.78bf8d48.svg"
  },
  {
    "revision": "a7f91db68b4b933c5d6825dfb10bcd69",
    "url": "img/metamask.a7f91db6.svg"
  },
  {
    "revision": "5b115a094d032013e9a3abba61868ff8",
    "url": "img/mew-collage-small.5b115a09.jpg"
  },
  {
    "revision": "00bbf48278a7812b4f80c3015f0090ab",
    "url": "img/mewwallet.00bbf482.svg"
  },
  {
    "revision": "d7e96ee32741923da0b538f5b40a5716",
    "url": "img/michael.d7e96ee3.jpg"
  },
  {
    "revision": "027995cc4b666d55b17eec6725e0761e",
    "url": "img/misha.027995cc.jpg"
  },
  {
    "revision": "4d8512231cb8f1d14f7220b225391c34",
    "url": "img/mobile-features-dapps.4d851223.svg"
  },
  {
    "revision": "3db0ebbdad96d9803bb07e1fbbe8d4ec",
    "url": "img/mobile-features-send.3db0ebbd.svg"
  },
  {
    "revision": "a15d3ab4af7cdf6ff29c08941bb08774",
    "url": "img/mobile-features-swap.a15d3ab4.svg"
  },
  {
    "revision": "22e08831c2f1170e4f77635f2b63be97",
    "url": "img/mobile-features-tokens.22e08831.svg"
  },
  {
    "revision": "a3deeb7c82c658629c98830478476703",
    "url": "img/my-tokens-table.a3deeb7c.svg"
  },
  {
    "revision": "e4671de22b4d3f1104fe71ebee5ca792",
    "url": "img/network.e4671de2.svg"
  },
  {
    "revision": "9ddaa47c3c8857309ecf26eb30ec57d6",
    "url": "img/new-dapps-page.9ddaa47c.png"
  },
  {
    "revision": "fbe76ba406d8e962da7992421e6a0fb9",
    "url": "img/olga.fbe76ba4.jpg"
  },
  {
    "revision": "4dc8e36944d2598315469fdf8ecefb31",
    "url": "img/paraswap.4dc8e369.png"
  },
  {
    "revision": "8366490e6ff5a9d5369521de52d84b38",
    "url": "img/placeholder.8366490e.jpg"
  },
  {
    "revision": "20ce3720f9e6f54808c97d9e052e5a5d",
    "url": "img/raden.20ce3720.jpg"
  },
  {
    "revision": "2f564a768af6a5f9bde60b119ac42e70",
    "url": "img/richie.2f564a76.jpg"
  },
  {
    "revision": "bdd892cdf337fc8975aca7ccab6ea06c",
    "url": "img/roboto-v20-latin-100.bdd892cd.svg"
  },
  {
    "revision": "dd0bea1f9a808d633492fa573039ca1d",
    "url": "img/roboto-v20-latin-300.dd0bea1f.svg"
  },
  {
    "revision": "95204ac95130828753c0ee0ada537c33",
    "url": "img/roboto-v20-latin-500.95204ac9.svg"
  },
  {
    "revision": "57888be7f3e68a7050452ea3157cf4de",
    "url": "img/roboto-v20-latin-700.57888be7.svg"
  },
  {
    "revision": "9c4bedeee9074a7ab438ff0e548d0fba",
    "url": "img/roboto-v20-latin-900.9c4bedee.svg"
  },
  {
    "revision": "8681f434273fd6a267b1a16a035c5f79",
    "url": "img/roboto-v20-latin-regular.8681f434.svg"
  },
  {
    "revision": "b8ec49ee738a99917c512eefcbac9db8",
    "url": "img/russell.b8ec49ee.jpg"
  },
  {
    "revision": "612bc13eb11188fe020b107d1672e451",
    "url": "img/semaja.612bc13e.jpg"
  },
  {
    "revision": "b4373e7b8bfbaa94f2d6a8ad1b933b59",
    "url": "img/send-tx-page.b4373e7b.png"
  },
  {
    "revision": "ef084bfd8dea233d2d4e568e2b7bca24",
    "url": "img/simplex.ef084bfd.png"
  },
  {
    "revision": "89f0fd941a585cca4c263d3c61e3c365",
    "url": "img/sirin.89f0fd94.png"
  },
  {
    "revision": "2af9e36c64afa58914ebc21e2d0d51bc",
    "url": "img/skale.2af9e36c.svg"
  },
  {
    "revision": "a52b3d53ae32eb0e55a23c04bc953dba",
    "url": "img/snippet-mew-wallet-confetti.a52b3d53.png"
  },
  {
    "revision": "4bd06de5220da1881da65639f200c820",
    "url": "img/swap-arrow.4bd06de5.svg"
  },
  {
    "revision": "db1544a42048ea3093180014cc370c75",
    "url": "img/swap-page.db1544a4.png"
  },
  {
    "revision": "3ae90c9908ceb97a350ffde954d36134",
    "url": "img/trezor.3ae90c99.svg"
  },
  {
    "revision": "c66f52ae0b4ec776d44d6ed0ae27ec98",
    "url": "img/trezor.c66f52ae.png"
  },
  {
    "revision": "d407a8e8013afe37d851d6dfd10eb209",
    "url": "img/uniswap.d407a8e8.png"
  },
  {
    "revision": "5aede8c5fd6c0298e235871b2fcc757b",
    "url": "img/usdc.5aede8c5.png"
  },
  {
    "revision": "0f48e38b7cfe58591814f96c623fb4e2",
    "url": "img/usdt.0f48e38b.png"
  },
  {
    "revision": "0cb21e89ef1f8a17339e2bb16c6fd708",
    "url": "img/vince.0cb21e89.jpg"
  },
  {
    "revision": "37f2bc6ecee2eb29b3cf6799ce58bf58",
    "url": "img/walletconnect.37f2bc6e.svg"
  },
  {
    "revision": "0b619167f601e6355364c4f63f0ca166",
    "url": "img/walletlink.0b619167.png"
  },
  {
    "revision": "d62f817e0fe784988015a8871d6255a7",
    "url": "img/xblaster.d62f817e.png"
  },
  {
    "revision": "cc102e0ab16352ff563169509c23a881",
    "url": "index.css"
  },
  {
    "revision": "043f6e5f8f8aeac7fd5ac5244c1aaa47",
    "url": "index.html"
  },
  {
    "revision": "64bb17c44d6a96d1a568",
    "url": "js/app~2e7e5c58.5eda0f58.js"
  },
  {
    "revision": "7a3c706ae9583780bc72",
    "url": "js/app~4b8fe208.93314925.js"
  },
  {
    "revision": "3e1374a0b471d5ee329e",
    "url": "js/app~4ef18728.ad0a9cc8.js"
  },
  {
    "revision": "8194ab8a780959acd394",
    "url": "js/app~5a11b65b.a754b62f.js"
  },
  {
    "revision": "3e729b3051c01ebeb12a",
    "url": "js/app~748942c6.b11a5b9e.js"
  },
  {
    "revision": "a0ea6236884fe618a076",
    "url": "js/app~abb6b261.084aac53.js"
  },
  {
    "revision": "4e42687e1300c882758f",
    "url": "js/app~d25e655e.90797ed7.js"
  },
  {
    "revision": "2f8f2f4903da65ee8014",
    "url": "js/app~ea7808b9.ca0f4165.js"
  },
  {
    "revision": "c1c5701acae08fce10c2",
    "url": "js/app~f71cff67.48c89336.js"
  },
  {
    "revision": "4a5dc6b3a7b7722b99d0",
    "url": "js/chunk-vendors~2a42e354.347ed5a8.js"
  },
  {
    "revision": "bcbc7edc3552469e2c55",
    "url": "js/chunk-vendors~6e8b5f81.67e80cc7.js"
  },
  {
    "revision": "38ece611421381f734d8",
    "url": "js/chunk-vendors~ec8c427e.b74d6358.js"
  },
  {
    "revision": "16685e735e7c7ea5fbcc022b6bac923f",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  },
  {
    "revision": "95f84509fae8191ea04b3936d704887a",
    "url": "spaceman.png"
  }
]);